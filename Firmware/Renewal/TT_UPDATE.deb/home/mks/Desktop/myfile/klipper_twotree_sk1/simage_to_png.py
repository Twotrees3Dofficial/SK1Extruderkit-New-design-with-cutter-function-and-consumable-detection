import base64
import sys
import numpy as np
from PIL import Image, ImageOps
from PIL import Image
from io import BytesIO

##第一个参数为gcode文件原文数据路径,第二个参数为生成png图片的路径

def simage_to_base64(input_simage,thumb_path):
    with open(input_simage,'r+') as fs:
        simage = fs.read()
    with open(thumb_path, "wb") as f:                       ##"with"语句用于自动管理文件的打开和关闭
        f.write(base64.b64decode(simage.encode()))

# 从命令行获取参数
if len(sys.argv) < 3:
    print("请提供图片路径和输出路径作为命令行参数")
else:
    input_simage = sys.argv[1]
    out_thumb_path = sys.argv[2]

    simage_to_base64(input_simage,out_thumb_path)
    #print("参数0 ", sys.argv[0]) #参数0是脚本名本身
    #print("参数1 ", sys.argv[1])
    #print("参数2 ", sys.argv[2])
    

