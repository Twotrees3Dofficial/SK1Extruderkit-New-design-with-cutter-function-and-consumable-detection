rm ~/gcode_files/plr -rf
