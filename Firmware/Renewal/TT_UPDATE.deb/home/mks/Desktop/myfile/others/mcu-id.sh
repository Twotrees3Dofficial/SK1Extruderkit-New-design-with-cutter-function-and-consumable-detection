#! /bin/bash

echo "$(date +%Y-%m-%d_%H-%M-%S)" > /root/debug_mcu-id.log
while [ ! -d /dev/serial/by-id ]; do
	echo "no id" >> /root/debug_mcu-id.log
	sleep 1
done

if [ -d "/dev/serial/by-id" ];then
	while [ "$(ls -A /dev/serial/by-id)" == "" ]
	do
		echo "empty id in /dev/serial/by-id" >> /root/debug_mcu-id.log
		sleep 1
	done
	path=$(ls /dev/serial/by-id/*)
	echo "get id info :$path" >> /root/debug_mcu-id.log
	if [ -f "/home/mks/klipper_config/MCU_ID.cfg" ];then
		content=$(cat /home/mks/klipper_config/MCU_ID.cfg)
		serial_content=$(echo "$content" | grep 'serial:' | awk -F'serial:' '{print $2}')
		if [[ -z "$serial_content" ]]; then
			echo "empty cfg serial:" >> /root/debug_mcu-id.log
			sed -i "s|serial:.*|serial:"${path}"|g" /home/mks/klipper_config/MCU_ID.cfg
			echo "set id finish" >> /root/debug_mcu-id.log
		else
			echo "MCU_ID.cfg serial: $serial_content" >> /root/debug_mcu-id.log
			if [ "$path" == "$serial_content" ]; then
				echo "nothing need to do with MCU_ID.cfg" >> /root/debug_mcu-id.log
			else
				echo "need to update MCU_ID.cfg" >> /root/debug_mcu-id.log
				sed -i "s|serial:.*|serial:"${path}"|g" /home/mks/klipper_config/MCU_ID.cfg
				echo "set id finish" >> /root/debug_mcu-id.log
			fi
		fi
	else
		touch /home/mks/klipper_config/MCU_ID.cfg
		echo '[mcu]' > /home/mks/klipper_config/MCU_ID.cfg
		echo 'serial:' >> /home/mks/klipper_config/MCU_ID.cfg
		echo 'restart_method: command' >> /home/mks/klipper_config/MCU_ID.cfg
		sed -i "s|serial:.*|serial:"${path}"|g" /home/mks/klipper_config/MCU_ID.cfg
		echo "set id finish" >> /root/debug_mcu-id.log
	fi
fi
